<?php


namespace app\modules\mch\controllers;


class StatisticController extends Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }
}
