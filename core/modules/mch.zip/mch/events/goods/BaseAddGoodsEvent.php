<?php
/**
 * @link:http://www.zjhejiang.com/
 * @copyright: Copyright (c) 2018 浙江禾匠信息科技有限公司
 *
 * Created by PhpStorm.
 * User: 风哀伤
 * Date: 2018/7/11
 * Time: 17:36
 */

namespace app\modules\mch\events\goods;


use Hejiang\Event\Event;
use Hejiang\Event\EventNameTrait;

class BaseAddGoodsEvent extends Event
{
    use EventNameTrait;
}