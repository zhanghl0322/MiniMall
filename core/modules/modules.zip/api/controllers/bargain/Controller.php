<?php
/**
 * @link:http://www.zjhejiang.com/
 * @copyright: Copyright (c) 2018 浙江禾匠信息科技有限公司
 *
 * Created by PhpStorm.
 * User: 风哀伤
 * Date: 2018/7/14
 * Time: 16:36
 */

namespace app\modules\api\controllers\bargain;


class Controller extends \app\modules\api\controllers\Controller
{

}