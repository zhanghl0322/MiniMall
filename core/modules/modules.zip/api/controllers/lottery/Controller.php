<?php

namespace app\modules\api\controllers\lottery;


class Controller extends \app\modules\api\controllers\Controller
{

}