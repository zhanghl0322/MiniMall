<?php
/**
 * Created by PhpStorm.
 * User: zc
 * Date: 2018/5/26
 * Time: 14:27
 */

namespace app\modules\mch\models\integralmall;

class integralmall
{

}
