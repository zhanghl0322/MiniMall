<?php
/**
 * @link:http://www.zjhejiang.com/
 * @copyright: Copyright (c) 2018 浙江禾匠信息科技有限公司
 *
 * Created by PhpStorm.
 * User: 风哀伤
 * Date: 2018/7/13
 * Time: 16:02
 */

namespace app\modules\mch\controllers\bargain;


class Controller extends \app\modules\mch\controllers\Controller
{
}