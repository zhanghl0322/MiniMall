<?php
namespace app\modules\mch\controllers\lottery;

class Controller extends \app\modules\mch\controllers\Controller
{

}