<?php

namespace app\modules\mch\controllers;


class PluginController extends Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }
}
