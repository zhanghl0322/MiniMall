<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/10/2
 * Time: 16:02
 */

namespace app\modules\admin\models;


class Model extends \app\models\Model
{
}