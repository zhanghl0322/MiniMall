<?php
/**
 * @copyright ©2018 浙江禾匠信息科技
 * @author Lu Wei
 * @link http://www.zjhejiang.com/
 * Created by IntelliJ IDEA
 * Date Time: 2018/6/22 13:57
 */


namespace app\modules\admin\models\password;

class Password
{
    const RESET_PASSWORD_SMS_CODE_VALIDATE_COUNT = 'RESET_PASSWORD_SMS_CODE_VALIDATE_COUNT';
    const RESET_PASSWORD_SMS_CODE = 'RESET_PASSWORD_SMS_CODE';
}
