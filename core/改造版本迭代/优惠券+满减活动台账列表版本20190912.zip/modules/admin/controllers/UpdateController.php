<?php

/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2017/8/3
 * Time: 14:36
 * Version: 1.5.2
 */

namespace app\modules\admin\controllers;


class UpdateController extends Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }
}
