<?php

defined('YII_ENV') or exit('Access Denied');
?>

<div style="position: relative">
    <img style="width: 100%;display: inline-block"
         src="<?= Yii::$app->request->baseUrl ?>/statics/admin/images/welcome.jpg">
</div>