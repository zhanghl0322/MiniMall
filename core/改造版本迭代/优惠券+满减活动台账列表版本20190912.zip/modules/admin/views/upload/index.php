<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
    <title></title>
</head>
<body>
upload
<script>
    if (typeof window.parent.uploadComplete !== 'undefined') {
        console.log(typeof window.parent.$);
    }
</script>
</body>
</html>