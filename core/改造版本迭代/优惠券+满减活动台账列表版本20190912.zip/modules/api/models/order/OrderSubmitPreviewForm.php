<?php
/**
 * @copyright ©2018 Lu Wei
 * @author Lu Wei
 * @link http://www.luweiss.com/
 * Created by IntelliJ IDEA
 * Date Time: 2018/7/26 15:42
 */


namespace app\modules\api\models\order;


use app\models\DiscountActivities;
use app\models\User;

class OrderSubmitPreviewForm extends OrderForm
{
    public function rules()
    {
        return parent::rules();
    }

    public function search()
    {

        if (!$this->validate())
            return $this->getErrorResponse();
        try{
            $mchList = $this->getMchListData();
            if($mchList['code'] == 1){
                return $mchList;
            }
            //TODO 外围统计多商户总订单金额 2019年8月28日15:52:13
            $order_total_price = 0;//默认值
            foreach ($mchList as $mch_item) {
                $order_total_price += $mch_item['total_price'];//Sum Order Price
            }

            //TODO 循环组装符合要求的优惠券  2019年8月28日17:28:49
            $new_coupon_list = [];
            foreach ($mchList as $mch_item) {
                foreach ($mch_item['coupon_list'] as $i => $coupon_item) {
                    \Yii::warning('================848484811====================='.$i,'info');
                    if($order_total_price>$coupon_item['min_price'])
                    {
                        \Yii::warning('================8484848====================='.$coupon_item['min_price'],'info');
                        $new_coupon_list[$i] = $coupon_item;
                    }
                }
            }

        }catch(\Exception $e){
            return [
                'code'=>1,
                'line' => $e->getLine(),
                'msg'=>$e->getMessage()
            ];
        }
        $user = User::findOne(['id' => $this->user_id]);

        //TODO 处理满减活动存在时  提示选择满减活动的问题 2019年9月11日16:59:32
        $discount_activities = DiscountActivities::findOne([
            'store_id' => $this->store_id,
            'is_delete' => 0,
            'is_join' => 2,
        ]);
        if(time() < $discount_activities->begin_time || time() > $discount_activities->end_time){
            $discount_activities=[];
            //return new ApiResponse(1, '满减活动暂未开始', []);
        }
        return [
            'code' => 0,
            'msg' => 'OOKK',
            'data' => [
                'pay_type_list' => $this->getPayTypeList(),
                'address' => $this->address,
                'level' => $this->getLevelData(),
                'mch_list' => $mchList,
                'coupon_list' => $new_coupon_list,//优惠券改造 2019年8月28日11:35:55
                'balances'=>$user->money,//TODO 时时返回账户余额
                'integral'=>$this->integral,
                'order_total_price'=>$order_total_price,
                'goods_card_list' => $this->goodsCardList(),
                'discount_activities_list'=>$discount_activities
            ],
        ];
    }
}