<?php

namespace app\models;

class MchRoleAdmin extends User
{

}
